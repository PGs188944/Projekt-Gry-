package ui;

import Game.Game;
import gamestates.Gamestate;
import gamestates.Menu;
import gamestates.Menu.*;
import utilz.LoadSave;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class IntroOverlay {
    private BufferedImage temp, thor;
    private BufferedImage[] bg;
    private int bg_scale = 2;
    private int thor_scale = 5;
    private int d_counter = 0;

    public IntroOverlay() {
        temp = LoadSave.GetSpriteAtlas(LoadSave.THOR);
        thor = temp.getSubimage(64, 2 * 64, 64, 64);
        temp = LoadSave.GetSpriteAtlas(LoadSave.DIALOGS);
        bg = new BufferedImage[8];
        for(int i=0; i <8; i++){
            bg[i] = temp.getSubimage(0, i*112, 223, 112);
        }

    }

    public void drawIntro(Graphics g) {
        g.setColor(new Color(0, 0, 0));
        g.fillRect(0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT);
        g.drawImage(thor, 150, 200, 64*thor_scale, 64*thor_scale, null);
        g.drawImage(bg[d_counter], 600, 200, 223 * bg_scale, 112 * bg_scale, null);

    }

    public boolean keyPressed(int e) {
        if (e == 0) {
            d_counter++;
            System.out.println("click");
            return  (d_counter == 8);
        }
        return false;
    }
}


