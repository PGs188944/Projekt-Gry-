package utilz;

import Game.Game;
import entities.Enemy;

public class constants {

    public static final float GRAVITY = 0.04f * Game.SCALE;
    public static final int ANI_SPEED =15;
    public static class ObjectConstants {

        public static final int HAMMER = 0;
        public static final int HAMMER_WIDTH_DEFAULT = 398;
        public static final int HAMMER_HEIGHT_DEFAULT = 396;
        public static final int HAMMER_WIDTH = (int) (Game.SCALE * HAMMER_WIDTH_DEFAULT/15);
        public static final int HAMMER_HEIGHT = (int) (Game.SCALE * HAMMER_HEIGHT_DEFAULT/15);

    }
    public static class EnemyConstants {
        public static final int WOLF = 0;

        public static final int WOLF_DRAWOFFSET_X = (int) (26 * Game.SCALE);
        public static final int WOLF_DRAWOFFSET_Y = (int) (27 * Game.SCALE);
        public static final int stand_R = 3;
        public static final int stand_L = 1;
        public static final int hit_L = 5;
        public static final int hit_R = 7;
        public static final int attack_L = 13;
        public static final int attack_R = 15;
        public static final int walking_R = 11;
        public static final int walking_L = 9;
        public static final int dead = 20;


        public static int GetSpriteAmount(int player_action) {
            switch (player_action) {
                case walking_L:
                case walking_R:
                    return 8;
                case attack_L:
                case attack_R:
                case dead:
                    return 6;
                case hit_L:
                case hit_R:
                    return 2;
                case stand_L:
                case stand_R:

                default:
                    return 1;
            }
        }

        public static int GetMaxHealth(int enemy_type){
            switch (enemy_type) {
                case WOLF:
                    return 10;
                default:
                    return 1;
            }
        }

        public static int GetEnemyDmg(int enemy_type){
            switch (enemy_type) {
                case WOLF:
                    return 15;
                default:
                    return 50;
            }
        }
    }

    public static class UI {


        public static class Buttons {
            public static final int B_WIDTH_DEFAULT = 140;
            public static final int B_HEIGHT_DEFAULT = 56;
            public static final int B_WIDTH = (int) (B_WIDTH_DEFAULT * Game.SCALE);
            public static final int B_HEIGHT = (int) (B_HEIGHT_DEFAULT * Game.SCALE);
        }

        public static class PauseButtons {
            public static final int SOUND_SIZE_DEFAULT = 42;
            public static final int SOUND_SIZE = (int) (SOUND_SIZE_DEFAULT * Game.SCALE);
        }

        public static class UrmButtons {
            public static final int URM_SIZE_DEFAULT = 56;
            public static final int URM_SIZE = (int) (URM_SIZE_DEFAULT * Game.SCALE);
        }
    }

    public static class Directions {

        public static final int LEFT = 2;
        public static final int RIGHT = 3;

    }

    public static class PlayerConstants {
        public static final int stand_R = 7;
        public static final int stand_L = 5;
        public static final int hit_L = 1;
        public static final int hit_R = 3;
        public static final int attack_L = 13;
        public static final int attack_R = 15;
        public static final int walking_R = 11;
        public static final int walking_L = 9;
        public static final int dead = 20;


        public static int GetSpriteAmount(int player_action) {
            switch (player_action) {
                case walking_L:
                case walking_R:
                    return 10;
                case attack_L:
                case attack_R:
                case dead:
                    return 6;
                case hit_L:
                case hit_R:
                    return 2;
                case stand_L:
                case stand_R:

                default:
                    return 1;
            }
        }
    }
}

