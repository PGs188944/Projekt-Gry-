package utilz;

import Game.Game;

import java.awt.*;
import java.awt.geom.Rectangle2D;

public class HelpMethods {
    public static boolean CanMoveHere(float x, float y, float width, float height, int[][] lvlDeta) {
        if (!IsSolid(x, y, lvlDeta))
            if (!IsSolid(x + width, y + height, lvlDeta)) //prawy dół
                if (!IsSolid(x + width, y, lvlDeta)) //prawa góra
                    if (!IsSolid(x, y + height, lvlDeta)) // lewy dół
                        return true;
        return false;
    }

    private static boolean IsSolid(float x, float y, int[][] lvlData) {
        int maxWidth = lvlData[0].length * Game.TITLES_SIZE;
        if (x < 0 || x >= maxWidth)
            return true;
        if (y < 0 || y >= Game.GAME_HEIGHT)
            return true;
        float xIndex = x / Game.TITLES_SIZE;
        float yIndex = y / Game.TITLES_SIZE;
        return IsTileSolid((int) xIndex, (int) yIndex, lvlData);

    }

    public static boolean IsTileSolid(int xTile, int yTile, int[][] lvlData) {
        int value = lvlData[yTile][xTile];

        if (value != 11 || value >= 48 || value <= 0)
            return true;
        return false;
    }

    public static float GetEntityXPosNextToWall(Rectangle2D.Float hitbox, float xSpeed, int[][] lvlData) {
        int currentTile = (int) (hitbox.x / Game.TITLES_SIZE);
        if (xSpeed > 0) {
            // Prawo
            int tileXpos = currentTile * Game.TITLES_SIZE;
            int xOffset = (int) (Game.TITLES_SIZE - hitbox.width);
            return tileXpos + xOffset - 1;
        } else {
            // Lewo
            return currentTile * Game.TITLES_SIZE;
        }
    }

    public static float GetEntityYPosOustideMap(Rectangle2D.Float hitbox, float airSpeed, int[][] lvlData) {
        int currentTile = (int) (hitbox.y / Game.TITLES_SIZE);
        if (airSpeed > 0) {
            // Upadanie
            int tileYpos = currentTile * Game.TITLES_SIZE;
            int yOffset = (int) (Game.TITLES_SIZE - hitbox.height);
            return tileYpos + yOffset + 47;
        } else {
            // Skok
            return currentTile * Game.TITLES_SIZE;
        }
    }

    public static boolean IsEntityOnFloor(Rectangle2D.Float hitbox, int[][] lvlData) {
        // Dolne rogi
        if (!IsSolid(hitbox.x, hitbox.y + hitbox.height + 1, lvlData))
            if (!IsSolid(hitbox.x + hitbox.width, hitbox.y + hitbox.height + 1, lvlData))
                return false;
        return true;

    }

    public static boolean isFloor(Rectangle2D.Float hitbox, float xSpeed, int[][] lvlData) {
        return IsSolid(hitbox.x + xSpeed, hitbox.y + hitbox.height + 1, lvlData);
    }

    public static boolean IsAllTilesWalkable(int xStart, int xEnd, int y, int[][] lvlData) {
        for (int i = 0; i < xEnd - xStart; i++) {
            if (IsTileSolid(xStart + i, y, lvlData)) {
                System.out.println("Ide");
                return false;
            }
            if (!IsTileSolid(xStart + i, y + 2, lvlData)) {
                System.out.println("Nie ide " + (int) ((xStart+i)*Game.TITLES_SIZE) + " " + (int)(y*Game.TITLES_SIZE));
                return false;
            }
        }
        return true;

    }

    public static boolean IsSightClear(int[][] lvlData, Rectangle2D.Float firstHitbox, Rectangle2D.Float secondHitbox, int yTile) {
        int firstXTile = (int) (firstHitbox.x / Game.TITLES_SIZE);
        int secondXTile = (int) (secondHitbox.x / Game.TITLES_SIZE);

        if (firstXTile > secondXTile)
            return IsAllTilesWalkable(secondXTile, firstXTile, yTile, lvlData);
        else
            return IsAllTilesWalkable(firstXTile, secondXTile, yTile, lvlData);


    }
}
