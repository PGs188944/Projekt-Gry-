package entities;

import Game.Game;
import gamestates.Playing;
import utilz.HelpMethods;
import utilz.LoadSave;

import java.awt.*;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.lang.reflect.Array;
import java.util.ArrayList;
import static utilz.constants.EnemyConstants.*;

public class EnemyManager {

    private Playing playing;
    private BufferedImage[][] wolfArr;
    private ArrayList<Wolf> wolves = new ArrayList<>();

    public EnemyManager(Playing playing) {
        this.playing = playing;
        loadEnemyImgs();
        addEnemies();
    }

    private void addEnemies() {
        wolves = LoadSave.GetWolfs();
        System.out.println("size of wolf: " + wolves.size());
    }

    public void update(int[][] lvlData, Player player) {
        for (Wolf w : wolves)
            if (w.isActive())
                w.update(lvlData,player);
    }

    public void draw(Graphics g, int xLvlOffset) {
        drawWolf(g, xLvlOffset);
    }

    private void drawWolf(Graphics g, int xLvlOffset) {
        for (Wolf w : wolves) {
            if (w.isActive()) {
                g.drawImage(wolfArr[w.getEnemyState()][w.getAniIndex()], (int) (w.getHitbox().x - WOLF_DRAWOFFSET_X) - xLvlOffset, (int) (w.getHitbox().y - WOLF_DRAWOFFSET_Y) - 15, (int) (80 * Game.SCALE), (int) (80 * Game.SCALE), null);
                //w.drawHitbox(g, xLvlOffset);
                //w.drawAttackBox(g, xLvlOffset);
            }
        }
    }

    public void checkEnemyHit(Rectangle2D.Float attackBox){
        for (Wolf w : wolves)
            if (w.isActive())
                if (attackBox.intersects(w.getHitbox())) {
                    w.hurt(10);
                    return;
                }

    }

    private void loadEnemyImgs() {
        wolfArr = new BufferedImage[21][13];
        BufferedImage temp = LoadSave.GetSpriteAtlas(LoadSave.WOLF_SPRITE);
        for (int j = 0; j < wolfArr.length; j++) {
            for (int i = 0; i < wolfArr[j].length; i++) {
                wolfArr[j][i] = temp.getSubimage(i * 64, j * 64, 64, 64);
            }
        }
    }

    public void resetAllEnemies() {
        for (Wolf w : wolves)
            w.resetEnemy();
    }
}
