package entities;

import Game.Game;
import utilz.constants;

import java.awt.geom.Rectangle2D;

import static utilz.constants.*;
import static utilz.constants.EnemyConstants.*;
import static utilz.HelpMethods.*;
import static utilz.constants.Directions.*;


public abstract class Enemy extends Entity {

    protected int aniIndex, enemyState = stand_L, enemyType;

    protected boolean firstUpdate = true;



    protected float walkSpeed = 0.4f * Game.SCALE;
    protected int walkDir = RIGHT;
    protected int tileY;
    protected float attackDistance = Game.TITLES_SIZE;
    protected int maxHealth;
    protected int currentHealth;
    protected boolean active = true;
    protected boolean attackChecked;



    public Enemy(float x, float y, int width, int height, int enemyType) {
        super(x, y, width, height);
        this.enemyType = enemyType;
        initHitbox(x, y, width, height);
        maxHealth = GetMaxHealth(enemyType);
        currentHealth = maxHealth;
        walkSpeed =  0.5f * Game.SCALE;
    }

    protected void firstUpdateCheck(int[][] lvlData) {
        if (!IsEntityOnFloor(hitbox, lvlData))
            inAir = true;
        firstUpdate = false;
    }

    protected void updateInAir(int[][] lvlData) {
        if (CanMoveHere(hitbox.x, hitbox.y, hitbox.width, hitbox.height, lvlData)) {
            hitbox.y += airSpeed;
            airSpeed += GRAVITY;
        } else {
            inAir = false;
            hitbox.y = GetEntityYPosOustideMap(hitbox, airSpeed, lvlData);
            tileY = (int) (hitbox.y / Game.TITLES_SIZE);
        }
    }

    protected void move(int[][] lvlData) {
        float xSpeed = 0;

        if (walkDir == RIGHT)
            xSpeed = -walkSpeed;
        else
            xSpeed = walkSpeed;

        if (CanMoveHere(hitbox.x + xSpeed, hitbox.y, hitbox.width, hitbox.height, lvlData))
            if (isFloor(hitbox, xSpeed, lvlData)) {
                hitbox.x += xSpeed;
                return;
            }

        changeWalkDir();
    }

    protected void turnTowardsPlayer(Player player) {
        if (player.hitbox.x > hitbox.x) {
            walkDir = LEFT;
            enemyState = walking_R;
        } else {
            walkDir = RIGHT;
            enemyState = walking_L;
        }
    }

    protected boolean canSeePlayer(int[][] lvlData, Player player) {
        int playerTileY = (int) (player.getHitbox().y / Game.TITLES_SIZE);
        if (playerTileY == tileY)
            if (isPlayerInRange(player)) {
                if (IsSightClear(lvlData, hitbox, player.hitbox, tileY)) {
                    return true;
                }
            }

        return false;
    }

    protected boolean isPlayerInRange(Player player) {
        int absValue = (int) Math.abs(player.hitbox.x - hitbox.x);
        return absValue <= attackDistance * 5;
    }

    protected boolean isPlayerCloseForAttack(Player player) {
        int absValue = (int) Math.abs(player.hitbox.x - hitbox.x);
        return absValue <= attackDistance;
    }

    protected void newState(int enemyState) {
        this.enemyState = enemyState;
        aniTick = 0;
        aniIndex = 0;
    }

    public void hurt(int amount){
        currentHealth -= amount;
        if(currentHealth <=0)
            newState(dead);
        else {
            if(walkDir == RIGHT)
                newState(hit_R);
            else
                newState(hit_L);
        }
    }
    protected void checkEnemyHit(Rectangle2D.Float attackBox, Player player) {
        if (attackBox.intersects(player.hitbox))
            player.changeHealth(-GetEnemyDmg(enemyType));
        attackChecked = true;
    }


    protected void updateAnimationTick() {
        aniTick++;
        if (aniTick >= ANI_SPEED) {
            aniTick = 0;
            aniIndex++;
            if (aniIndex >= GetSpriteAmount(enemyState)) {
                aniIndex = 0;

                switch (enemyState){
                    case attack_L:
                    case hit_L:
                        enemyState = stand_L;
                        break;
                    case attack_R:
                    case hit_R:
                        enemyState = stand_R;
                        break;
                    case dead:
                        active = false;
                }

            }
        }
    }


    protected void changeWalkDir() {
        if (walkDir == LEFT) {
            walkDir = RIGHT;
            enemyState = walking_L;
        } else {
            walkDir = LEFT;
            enemyState = walking_R;

        }
    }

    public void resetEnemy() {
        hitbox.x = x;
        hitbox.y = y;
        firstUpdate = true;
        currentHealth = maxHealth;
        newState(stand_L);
        walkDir = RIGHT;
        active = true;
        airSpeed = 0;
    }

    public int getAniIndex() {
        return aniIndex;
    }

    public int getEnemyState() {
        return enemyState;
    }

    public boolean isActive(){
        return active;
    }
}
