package entities;

import Game.Game;

import java.awt.*;

import static utilz.HelpMethods.*;
import static utilz.constants.Directions.LEFT;
import static utilz.constants.Directions.RIGHT;
import static utilz.constants.PlayerConstants.*;
import static utilz.constants.EnemyConstants.*;

public class Wolf extends Enemy {
    public Wolf(float x, float y) {
        super(x, y, (int) (64 * Game.SCALE), (int) (64 * Game.SCALE), WOLF);
        initHitbox(x, y, (int) (30*Game.SCALE),(int) (37*Game.SCALE));

    }

    public void update(int[][] lvlData, Player player) {
        updateMove(lvlData,player);
        updateAnimationTick();
    }

    private void updateMove(int [][] lvlData, Player player){
        if (firstUpdate)
            firstUpdateCheck(lvlData);

        if(inAir)
          updateInAir(lvlData);
        else {
            switch (enemyState){
                case stand_L:
                    newState(walking_L);
                    break;
                case stand_R:
                    newState(walking_R);
                    break;
                case walking_R:
                case walking_L:
                    //System.out.println("wolf " + (int)hitbox.x + " player " + (int)player.hitbox.x + " sight " + Game.TITLES_SIZE);

                    if (canSeePlayer(lvlData, player)) {
                        turnTowardsPlayer(player);
                        System.out.println("Widze cie");
                    }
                    if (isPlayerCloseForAttack(player)){
                        if (walkDir == RIGHT)
                            newState(attack_L);
                        else
                            newState(attack_R);
                    }
                    move(lvlData);
                    break;
            }
        }


    }
}
