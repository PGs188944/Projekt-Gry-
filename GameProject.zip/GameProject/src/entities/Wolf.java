package entities;

import Game.Game;

import javax.management.MBeanAttributeInfo;
import java.awt.*;
import java.awt.geom.Rectangle2D;

import static utilz.HelpMethods.*;
import static utilz.constants.Directions.LEFT;
import static utilz.constants.Directions.*;
import static utilz.constants.EnemyConstants.*;

public class Wolf extends Enemy {
    //Attack

    private int attackBoxOffsetX, attackBoxOffsetY;
    public Wolf(float x, float y) {
        super(x, y, (int) (64 * Game.SCALE), (int) (64 * Game.SCALE), WOLF);
        initHitbox(x, y, (int) (30*Game.SCALE),(int) (37*Game.SCALE));
        initAttackBox();
    }
    private void initAttackBox() {
        attackBox = new Rectangle2D.Float(x, y, (int) (20 * Game.SCALE), (int) (20 * Game.SCALE));
        attackBoxOffsetX = (int) (Game.SCALE * 20);
        attackBoxOffsetY = (int) (Game.SCALE * 10);
    }

    public void update(int[][] lvlData, Player player) {
        updateBehavior(lvlData,player);
        updateAnimationTick();
        updateAttackBox();

    }

    private void updateAttackBox() {
        if (walkDir == RIGHT) {
            attackBox.x = hitbox.x - attackBoxOffsetX;
            attackBox.y = hitbox.y + attackBoxOffsetY;
        }
        else {
            attackBox.x = hitbox.x - attackBoxOffsetX + 2*hitbox.width - 10;
            attackBox.y = hitbox.y + attackBoxOffsetY;
        }

    }

    private void updateBehavior(int [][] lvlData, Player player){
        if (firstUpdate)
            firstUpdateCheck(lvlData);

        if(inAir)
          updateInAir(lvlData);
        else {
            switch (enemyState){
                case stand_L:
                    newState(walking_L);
                    break;
                case stand_R:
                    newState(walking_R);
                    break;
                case walking_R:
                case walking_L:

                    if (canSeePlayer(lvlData, player)) {
                        turnTowardsPlayer(player);
                        if (isPlayerCloseForAttack(player)) {
                            if (walkDir == RIGHT)
                                newState(attack_L);
                            else
                                newState(attack_R);
                        }
                    }
                    move(lvlData);
                    break;
                case attack_L:
                case attack_R:
                    if (aniIndex == 0)
                        attackChecked = false;

                    if(aniIndex == 5 && !attackChecked)
                        checkEnemyHit(attackBox, player);
                    break;
                case hit_L:
                case hit_R:
                    break;
            }
        }
    }


    public void drawAttackBox(Graphics g, int xLvlOffset) {
        g.setColor(Color.red);
        g.drawRect((int) (attackBox.x - xLvlOffset), (int) attackBox.y, (int) attackBox.width, (int) attackBox.height);
    }
}
