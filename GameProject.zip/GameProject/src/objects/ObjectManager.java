package objects;

import entities.Player;
import gamestates.Playing;
import levels.Level;
import utilz.LoadSave;

import java.awt.*;
import java.awt.image.BufferedImage;
import static utilz.constants.ObjectConstants.*;

public class ObjectManager {
    private Playing playing;
    private Hammer hammer;
    private BufferedImage hammerImg;

    private Level currentLevel;

    public ObjectManager(Playing playing) {
        this.playing = playing;
        hammerImg = LoadSave.GetSpriteAtlas(LoadSave.HAMMER);

        hammer = new Hammer(2220, 430, HAMMER);
    }


    public void update() {
        if (hammer.isActive())
            hammer.update();
    }

    public void draw(Graphics g, int xLvlOffset) {
        if (hammer.isActive())
            g.drawImage(hammerImg, (int) (hammer.getHitbox().x - hammer.getxDrawOffset() - xLvlOffset), (int) (hammer.getHitbox().y - hammer.getyDrawOffset()), HAMMER_WIDTH,
                    HAMMER_HEIGHT, null);
    }

}
