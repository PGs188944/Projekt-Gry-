package levels;

import java.awt.*;
import java.awt.image.BufferedImage;

import static utilz.HelpMethods.GetHammerSpawn;

public class Level {

    private int[][] lvlData;
    private Point hammerSpawn;
    private BufferedImage img;
    public Level(int[][] lvlData, BufferedImage img){
        this.img = img;
        this.lvlData = lvlData;
        calcHammerSpawn();

    }

    private void calcHammerSpawn() {
        hammerSpawn = GetHammerSpawn(img);
    }

    public int getSpriteIndex(int x, int y){
        return lvlData[y][x];
    }

    public int[][] getLvlData(){
        return lvlData;
    }

    public Point getHammerSpawn() {
        return hammerSpawn;
    }
}

