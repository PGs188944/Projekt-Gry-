package gamestates;

import Game.Game;
import ui.MenuButton;
import utilz.LoadSave;
import ui.IntroOverlay;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

public class Menu extends State implements Statemethods {

    private MenuButton[] buttons = new MenuButton[3];
    private BufferedImage backgroungImg, wallpaper;
    private IntroOverlay introOverlay;
    private int menuX, menuY, menuWidth, menuHeight;
    private boolean fistStart = true;

    public Menu(Game game) {
        super(game);
        loadButtons();
        loadBackground();
        if (fistStart)
            loadIntro();
        wallpaper = LoadSave.GetSpriteAtlas(LoadSave.MENU_WALLPAPER);

    }
    private void loadIntro() {
        introOverlay = new IntroOverlay();
    }

    private void loadBackground() {
        backgroungImg = LoadSave.GetSpriteAtlas(LoadSave.MENU_BACKGROUND);
        menuWidth = (int) (backgroungImg.getWidth() * Game.SCALE);
        menuHeight = (int) (backgroungImg.getHeight() * Game.SCALE);
        menuX = Game.GAME_WIDTH / 2 - menuWidth / 2;
        menuY = (int) (45 * Game.SCALE);
    }

    private void loadButtons() {
        buttons[0] = new MenuButton(Game.GAME_WIDTH / 2, (int) (150 * Game.SCALE), 0, Gamestate.PLAYING);
        buttons[1] = new MenuButton(Game.GAME_WIDTH / 2, (int) (220 * Game.SCALE), 1, Gamestate.OPTIONS);
        buttons[2] = new MenuButton(Game.GAME_WIDTH / 2, (int) (290 * Game.SCALE), 2, Gamestate.QUIT);
    }

    @Override
    public void update() {
        for (MenuButton mb : buttons)
            mb.update();
    }

    @Override
    public void draw(Graphics g) {

        g.drawImage(wallpaper, 0, 0, Game.GAME_WIDTH, Game.GAME_HEIGHT, null);

        g.drawImage(backgroungImg, menuX, menuY, menuWidth, menuHeight, null);

        for (MenuButton mb : buttons)
            mb.draw(g);
        if (fistStart)
            introOverlay.drawIntro(g);
    }

    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {
        if (!fistStart)
            for (MenuButton mb : buttons) {
                if (isIn(e, mb)) {
                    mb.setMousePressed(true);
                    break;
                }
            }

    }

    @Override
    public void mouseReleased(MouseEvent e) {
        for (MenuButton mb : buttons) {
            if (isIn(e, mb)) {
                if (mb.isMousePressed())
                    mb.applyGamestate();
                break;
            }
        }
        resetButtons();
    }

    private void resetButtons() {
        for (MenuButton mb : buttons)
            mb.resetBools();
    }

    @Override
    public void mouseMoved(MouseEvent e) {
        if (!fistStart) {
            for (MenuButton mb : buttons)
                mb.setMouseOver(false);

            for (MenuButton mb : buttons) {
                if (isIn(e, mb)) {
                    mb.setMouseOver(true);
                    break;
                }
            }
        }
    }

    @Override
    public void keyPressed(int e) {
        if (e == 0) {
            if (introOverlay.keyPressed(e))
                fistStart = false;
        }
        if (e == 3)
            Gamestate.state = Gamestate.PLAYING;
    }

    @Override
    public void keyReleased(int e) {

    }
}
